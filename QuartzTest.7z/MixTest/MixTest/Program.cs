﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Topshelf;

namespace MixTest
{
    class Program
    {
        static void Main(string[] args)
        {
            HostFactory.Run(x =>                                 //1
            {
                x.Service<ServiceRunner>();
                x.RunAsLocalSystem();

                x.SetDescription("MixTest Start");        //7
                x.SetDisplayName("MixTest");                       //8
                x.SetServiceName("MixTest");                       //9

                x.UseNLog();
            });
        }
    }
}
